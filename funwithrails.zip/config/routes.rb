Rails.application.routes.draw do
  root 'application#goodbye'
end